# Blind Five

Blind Five is a basketball guessing game where you build a five-player lineup without seeing player identities up front.

## How to play

1. Draft one mystery player at each position in order: PG, SG, SF, PF, then C.
2. Each round gives you three starting hints for five hidden options.
3. Pick one option. The five identities and tiers are revealed, and your selection is locked into the lineup.
4. Continue through all five positions to simulate the season.
5. Use Draft Again to start a fresh draft.

## Powerups

- **Team Check** reveals the team clue for all five options in the current round.
- **Timeline** reveals the active years for all five options in the current round.
- **Scout** reveals the scouting clue for all five options in the current round.
- **Franchise Player** guarantees that an ALL-TIMER is somewhere in the current
  round without revealing which option it is.

Each powerup can be used once per draft, before a player is picked in the
current round. Used powerups stay consumed as you move through the lineup and
reset when you draft again.

## Tier system

Rounds select five unique players using weighted tier rarity:

- **ALL TIMER** — 5%
- **ALL STAR** — 15%
- **SOLID** — 35%
- **BENCH** — 30%
- **BUST** — 15%

Duplicate tiers are allowed, and no tier is guaranteed. Tier values are:

- **ALL TIMER** — 5 points
- **ALL STAR** — 4 points
- **SOLID** — 3 points
- **BENCH** — 2 points
- **BUST** — 1 point

## Season simulation

When the draft is complete, the five tier values create a team score from 5 to 25. The win probability is calculated as:

```text
strength = (teamScore - 5) / 20
winProbability = 0.18 + strength * 0.64
```

The game simulates exactly 82 games using that probability and displays the resulting wins, losses, team rating, and lineup. The result is generated once when the draft finishes; React rerenders do not reroll it. A new draft uses fresh randomness, so the same lineup can produce a different record.

## Stack

- React
- TypeScript
- Vite
- Vitest
- CSS with the existing court-inspired visual system

## V1 scope

V1 is a single-player, client-side drafting game with a 500-player pool,
five-position progression, one-use powerups, and probabilistic season results.
It does not include accounts, multiplayer, persistence, leaderboards, or a
backend.